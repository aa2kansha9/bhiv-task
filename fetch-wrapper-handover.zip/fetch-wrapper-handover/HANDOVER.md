# FetchWrapper API Workflow - Handover Document

## Overview
This document provides everything needed to understand, run, and maintain the FetchWrapper API workflow.

## How to Use/ Run
open live server at form.html and then open in browser to test the project 

### For Browser Projects:
1. Copy `src/fetchWrapper.js` and `src/config.js` to your project
2. Import and instantiate:
   ```javascript
   import FetchWrapper from './fetchWrapper.js';
   const api = new FetchWrapper('https://api.example.com');
   api.setToken('your-token');