import FetchWrapper from '../src/fetchWrapper.js';

// Simple mock for fetch
let fetchCalls = [];
let mockResponses = [];

global.fetch = async (url, options) => {
    fetchCalls.push({ url, options });
    
    // Return first mock response
    if (mockResponses.length > 0) {
        const response = mockResponses.shift();
        return response;
    }
    
    // Default success response
    return {
        ok: true,
        status: 200,
        headers: { get: () => 'application/json' },
        json: async () => ({ success: true })
    };
};

function resetMocks() {
    fetchCalls = [];
    mockResponses = [];
}

async function runTests() {
    console.log('🚀 Running FetchWrapper Tests\n');
    let passed = 0;
    let failed = 0;

    // Test 1: Instance creation
    try {
        const api = new FetchWrapper('https://api.test.com');
        if (api.baseURL === 'https://api.test.com') {
            console.log('✅ Test 1: Instance created successfully');
            passed++;
        } else {
            throw new Error('Base URL not set correctly');
        }
    } catch (error) {
        console.log('❌ Test 1 failed:', error.message);
        failed++;
    }

    // Test 2: Token injection
    try {
        resetMocks();
        const api = new FetchWrapper('https://api.test.com');
        api.setToken('test-token-123');
        
        // Mock response
        mockResponses.push({
            ok: true,
            headers: { get: () => 'application/json' },
            json: async () => ({ success: true })
        });
        
        await api.get('/test');
        
        const lastCall = fetchCalls[0];
        if (lastCall.options.headers.Authorization === 'Bearer test-token-123') {
            console.log('✅ Test 2: Token injected correctly');
            passed++;
        } else {
            throw new Error('Token not found in headers');
        }
    } catch (error) {
        console.log('❌ Test 2 failed:', error.message);
        failed++;
    }

    // Test 3: Error handling (4xx)
    try {
        resetMocks();
        const api = new FetchWrapper('https://api.test.com');
        
        // Mock 400 error
        mockResponses.push({
            ok: false,
            status: 400,
            statusText: 'Bad Request'
        });
        
        await api.get('/error');
        console.log('❌ Test 3: Should have thrown error but did not');
        failed++;
    } catch (error) {
        if (error.message.includes('HTTP 400')) {
            console.log('✅ Test 3: Correctly caught 400 error');
            passed++;
        } else {
            console.log('❌ Test 3: Wrong error:', error.message);
            failed++;
        }
    }

    // Test 4: Config usage
    try {
        const api = new FetchWrapper(); // Should use default from config
        if (api.retryAttempts === 3) { // From config.js
            console.log('✅ Test 4: Config values loaded correctly');
            passed++;
        } else {
            throw new Error('Config not loaded');
        }
    } catch (error) {
        console.log('❌ Test 4 failed:', error.message);
        failed++;
    }

    console.log('\n📊 Test Results:');
    console.log(`   Passed: ${passed}`);
    console.log(`   Failed: ${failed}`);
    console.log(`   Total: ${passed + failed}`);
    
    if (failed === 0) {
        console.log('\n🎉 All tests passed!');
    } else {
        console.log('\n⚠️ Some tests failed');
        process.exit(1);
    }
}

runTests();