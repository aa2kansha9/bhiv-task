import FetchWrapper from '../src/fetchWrapper.js';

async function test() {
    // Use a REAL, reliable public test API
    const api = new FetchWrapper('https://jsonplaceholder.typicode.com');
    
    console.log('Testing with REAL public API...');
    
    try {
        // Test 1: GET request
        console.log('\n1. Testing GET request:');
        const post = await api.get('/posts/1');
        console.log('   ✅ GET success:', post.id ? `Got post #${post.id}` : 'Received data');
        
        // Test 2: POST request (simulating form submission)
        console.log('\n2. Testing POST request (form simulation):');
        const newPost = await api.post('/posts', {
            title: 'Test Form Submission',
            body: 'This simulates form data',
            userId: 1
        });
        console.log('   ✅ POST success:', newPost.id ? `Created post #${newPost.id}` : 'Data submitted');
        
        // Test 3: Error handling
        console.log('\n3. Testing error handling:');
        try {
            await api.get('/nonexistent-endpoint');
        } catch (error) {
            console.log('   ✅ Error caught:', error.message.includes('HTTP') ? error.message : 'Request failed');
        }
        
        console.log('\n🎉 All tests passed! FetchWrapper is working correctly.');
        
    } catch (error) {
        console.log('❌ Main test failed:', error.message);
        console.log('Check internet connection or API availability.');
    }
}

test();