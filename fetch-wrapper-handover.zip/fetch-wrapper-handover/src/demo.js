import FetchWrapper from './fetchWrapper.js';
import config from './config.js';

async function runDemo() {
    console.log('=== FetchWrapper Demo ===\n');
    
    // Example 1: Basic GET request
    console.log('1. Testing GET request:');
    const api = new FetchWrapper(config.BASE_URL);
    
    try {
        const posts = await api.get('/posts/1');
        console.log('   Success:', JSON.stringify(posts, null, 2).split('\n')[0] + '...');
    } catch (error) {
        console.log('   Error:', error.message);
    }
    
    // Example 2: POST with data
    console.log('\n2. Testing POST request:');
    try {
        const newPost = await api.post('/posts', {
            title: 'Test Post',
            body: 'This is a test',
            userId: 1
        });
        console.log('   Created post ID:', newPost.id || 'N/A');
    } catch (error) {
        console.log('   Error:', error.message);
    }
    
    // Example 3: With token injection
    console.log('\n3. Testing with token injection:');
    const secureApi = new FetchWrapper('https://api.test.com');
    secureApi.setToken('demo-token-123');
    console.log('   Token set for Authorization header');
    
    // Example 4: Error handling
    console.log('\n4. Testing error handling (invalid endpoint):');
    try {
        await api.get('/invalid-endpoint-9999');
    } catch (error) {
        console.log('   Handled error:', error.message);
    }
    
    console.log('\n=== Demo Complete ===');
    console.log('\nTo run the web form:');
    console.log('1. Run: npm run demo');
    console.log('2. Or open src/form.html in your browser');
}

runDemo();