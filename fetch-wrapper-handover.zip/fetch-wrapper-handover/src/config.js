// Configuration for FetchWrapper - Works in both Node.js and Browser
const config = {
    // API Base URL
    BASE_URL: 'https://jsonplaceholder.typicode.com',
    
    // Maximum retry attempts for failed requests
    MAX_RETRIES: 3,
    
    // Initial retry delay in milliseconds
    RETRY_DELAY: 1000,
    
    // Enable/disable token injection
    USE_AUTH: false,
    
    // Default token
    DEFAULT_TOKEN: null
};

// Only use process.env in Node.js environment
if (typeof process !== 'undefined' && process.env) {
    config.BASE_URL = process.env.API_BASE_URL || config.BASE_URL;
    config.MAX_RETRIES = process.env.MAX_RETRIES ? parseInt(process.env.MAX_RETRIES) : config.MAX_RETRIES;
    config.RETRY_DELAY = process.env.RETRY_DELAY ? parseInt(process.env.RETRY_DELAY) : config.RETRY_DELAY;
    config.USE_AUTH = process.env.USE_AUTH === 'true' || config.USE_AUTH;
    config.DEFAULT_TOKEN = process.env.API_TOKEN || config.DEFAULT_TOKEN;
}

export default config;